<?php

$nama = "Wiwin Suminar" ;
$nim = "10220022" ;
$matakuliah = "Pemrograman Platform Khusus";
$partisipasi = 16;
$tugas = 90;
$uts = 83;
$uas =80;

//buatlah rumus untuk menghitung nilai akhir dar mahasiswa
$nilaiAkhir = $partisipasi*0.1 + $uts*0.2 + $uas*0.3 + $tugas*0.4;
//menampilkan rumus untuk menghitung nilai akhir dari mahasiswa
echo '<h1'.'<b'."Menghitung Nilai Akhir Mahasiswa".'</b>'.'</h1>';
echo "Nama Mahasiswa :".'<b>'.$nama.'</b>'.'<br>';
echo "NIM :".'<b>'.$nim.'</b>'.'<br>';
echo "Mata Kuliah :".'<b>'$matakuliah.'</b>'.'<br>';
echo "Nilai Absen :".'<b>'$partisipasi.'</b>'.'<br>';
echo "Nilai Tugas :".'<b>'$tugas.'</b>'.'<br>';
echo "UTS :".'<b>'$uts.'</b>'.'<br>';
echo "UAS :".'<b>'$uas'</b>'.'<br>';

echo "Nilai Akhir adalah ".'<b>'.$nilaiAkhir.'</b>'.'<br>';

if($nilaiAkhir>=60) {
    echo"Anda mendapat nilai A".'<br>';
}
    else
    echo " Anda Tidak Lulus".'<br>';

    if($nilaiAkhir>=85){
        echo "Grade A";     
    } elseif ($nilaiAkhir>=80){
        echo "Grade A-";
    } elseif ($nilaiAkhir>=70){
        echo "Grade B+";
    } elseif ($nilaiAkhir>=65){
        echo "Grade B";
    } elseif ($nilaiAkhir>=60){
        echo "Grade B-";
    } elseif ($nilaiAkhir>=50){
        echo "Grade C+";
    } elseif ($nilaiAkhir>=40){
        echo "Grade C";
    } elseif ($nilaiAkhir>=30){
        echo "Grade D";
    } else
        echo "Grade E";


?>